/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

/**
 *
 * @author User
 */
public class Student1 {
    private int id;
    private String nume_student;
    private int nr_matricol;
    private int an_stud;
    private int grupa;
    private int nota1;
    private int nota2;
    private int nota3;
    private int media;
 
    public Student1( int ID, String Nume_Student,int Nr_Matricol,int An_Stud,int Grupa, int Nota1, int Nota2, int Nota3,int Media )
    {   this.id=ID;
        this.nume_student=Nume_Student;
        this.nr_matricol=Nr_Matricol;
        this.an_stud=An_Stud;
        this.grupa=Grupa;
        this.nota1=Nota1;
        this.nota2=Nota2;
        this.nota3=Nota3;
        this.media=Media;
    }
    
     public int getId()
    {
        return id;
    }
     
    public String getNume_Student()
    {
        return nume_student;
    }
    
    public int getNr_Matricol()
    {
        return nr_matricol;
    }
    
    public int getAn_Stud()
    {
        return an_stud;
    }
    
    public int getGrupa()
    {
        return grupa;
    }
    
    public int getNota1()
    {
        return nota1;
    }
     
    public int getNota2()
    {
        return nota2;
    }
      
    public int getNota3()
    {
        return nota3;
    }
       
    public int getMedia()
    {
        return media;
    } 
}
